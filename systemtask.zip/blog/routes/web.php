<?php
### LOGIN START###
Route::get('/','LoginController@index');
Route::get('login','LoginController@index');
Route::post('logincheck','LoginController@check');
Route::get('logout','LoginController@logout');
### END ###

### EVENT START ###
Route::get('dashboard','DashboardController@index');
Route::post('ajaxevent','DashboardController@ajaxevent');
Route::get('newevent','DashboardController@newevent');
Route::post('addevent','DashboardController@addevent');
Route::post('deleteevent','DashboardController@deleteevent');
Route::get('editevent','DashboardController@editevent');
Route::post('updateevent','DashboardController@updateevent');
Route::post('searchevent','DashboardController@searchevent');
### EVENT END ###