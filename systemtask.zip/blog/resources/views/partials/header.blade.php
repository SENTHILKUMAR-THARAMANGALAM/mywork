<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title>My Work</title>
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
      <link rel="stylesheet" href="{{ url('css/bootstrap.min.css')}}">
      <link rel="stylesheet" href="{{ url('css/font-awesome.min.css')}}">
      <link rel="stylesheet" href="{{ url('css/ionicons.min.css')}}">
      <link rel="stylesheet" href="{{ url('css/mywork.css')}}">
      <link rel="stylesheet" href="{{ url('css/blue.css')}}">
      <link rel="stylesheet" href="{{ url('css/skins.min.css')}}">
      <link rel="stylesheet" href="{{ url('css/dataTables.bootstrap.min.css')}}">
      <link rel="stylesheet" href="{{ url('css/responsive.dataTables.min.css')}}">
      <link rel="stylesheet" href="{{ url('css/jquery-confirm.min.css')}}">
      <link rel="stylesheet" href="{{ url('css/pagination.css')}}">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
      <script src="{{ url('js/jquery.min.js')}}"></script>
   </head>
   <body class="hold-transition skin-blue layout-top-nav">
      <div class="wrapper">
      <header class="main-header">
         <nav class="navbar navbar-static-top">
            <div class="container">
               <div class="navbar-header">
					<span class="navbar-brand">My Work</span>
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
                  <i class="fa fa-bars"></i>
                  </button>
               </div>
               <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
                  <ul class="nav navbar-nav">
                     <li class="actives"><a href="{{url('dashboard')}}">Dashaoard</a></li>
                  </ul>
               </div>
               <div class="navbar-custom-menu">
                  <ul class="nav navbar-nav">
                     <li class="dropdown user user-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <img src='{{url("images/user_icon/user.png")}}' class="user-image" alt="User Image">
                        <span class="hidden-xs">Admin</span>
                        </a>
                        <ul class="dropdown-menu">
                           <li class="user-header">
                              <img src="{{url('images/user_icon/user.png')}}" class="img-circle" alt="User Image">
                              <p>Admin</p>
                           </li>
                           <li class="user-footer">
                              <!--<div class="pull-left">
                                 <a href="#" class="btn btn-default btn-flat">Profile</a>
                                 </div>-->
                              <center>
                                 <div class="pull-rights">
                                    <a href="logout" class="btn btn-default btn-flat">Sign out</a>
                                 </div>
                              </center>
                           </li>
                        </ul>
                     </li>
                  </ul>
               </div>
            </div>
         </nav>
      </header>