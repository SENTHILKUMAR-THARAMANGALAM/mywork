<script src="{{ url('js/bootstrap.min.js')}}"></script>
<script src="{{ url('js/mywork.min.js')}}"></script>
<script src="{{ url('js/demo.js')}}"></script>
<script src="{{ url('js/jquery.dataTables.min.js')}}"></script>
<script src="{{ url('js/dataTables.responsive.min.js')}}"></script>
<script src="{{ url('js/jquery-confirm.min.js')}}"></script>
<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>My Work</b>
      </div>
      <strong>Copyright © <?php echo date('Y'); ?>  All rights reserved.</strong>
    </div>
  </footer>
</div>
</body>
</html>
