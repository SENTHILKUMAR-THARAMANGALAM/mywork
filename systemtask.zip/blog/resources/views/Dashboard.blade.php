@extends('layouts.master')
@section('content')
<div class="content-wrapper">
   <div class="container">
      <section class="content">
         <div class="row">
            <div class="box">
               <div class="box-header">
                  <h3 class="box-title"><b>Event Management</b></h3>
               </div>
               <div class="box-body">
                  <div class="row">
                     <div class="form-group">
                        <div class="col-sm-2">
                           <label for="startdate">Start Date</label>
                           <input type="text" class="form-control date" id="startdate" placeholder="Start Date" autocomplete="off">
                        </div>
                     
                        <div class="col-sm-2">
                           <label for="startdate">End Date</label>
                           <input type="text" class="form-control date" id="enddate" placeholder="End Date"autocomplete="off" >
                        </div>
                     
                        <div class="col-sm-2">
                           <label for="startdate">Tag</label>
                           <select name="eventtags" id="eventtags" class="form-control" required >
                              <option value="">Select Tags</option>
                              <option value="Red">Red</option>
                              <option value="Green">Green</option>
                              <option value="Blue">Blue</option>
                              <option value="Yellow">Yellow</option>
                           </select>
                        </div>
						<div class="col-sm-2">
                           <label for="startdate"></label><br>
                           <button class="search btn btn-primary">Search</button>
                        </div>
						<div class="col-sm-2">
                           
                        </div>
						<div class="col-sm-2">
                           <label for="startdate"></label><br>
						   <a href="{{url('newevent')}}"><button class="btn btn-info btn-sm">Add Event</button></a>
                        </div>
                     </div>
                  </div><br>
                  <table id="example" class="table table-bordered table-striped dataTable" role="grid" aria-describedby="example1_info">
                     <thead>
                        <tr role="row">
                           <th>Event</th>
                           <th>Start Date</th>
                           <th>End Date</th>
                           <th>Place</th>
                           <th>Tags</th>
                           <th>Price</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody id="tablebody">
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </section>
   </div>
</div>
<link rel="stylesheet" href="{{url('css/daterangepicker.css')}}">
<script src="{{url('js/daterangepicker.js')}}"></script>
<script  type="text/javascript">
   $(document).ready(function(){
   	//alert();
   	$('#example').DataTable({
   	  processing: true,
   	  serverSide: true,
   	  ajax:{
   	   url: "{{ url('ajaxevent') }}",
   	   type: "POST",
   	   data: {"_token": "{{ csrf_token() }}"},
   	  },
   	  columns:[
   	  { data: 'event',name: 'event'},
   	  { data: 'start_date',name: 'start_date' },
   	  { data: 'end_date',name: 'end_date' },
   	  { data: 'place',name: 'place'},
   	  { data: 'tags',name: 'tags'},
   	  { data: 'price',name: 'price'},
   	  { data: 'action',name: 'action',orderable: false},],
   	  bDestroy: true,
   	});
   });
   $(document).on('click','.delete', function(){
   	var id = '';
	var tr  = '';
   	var id = $(this).attr("data-id");
   	var tr  = $(this).closest("tr");
   	
	$.confirm({
		title: 'Are you sure you want to delete',
		buttons: {
		confirm: function () {
			$.ajax({
			url: "{{ url('deleteevent') }}",
			type: "POST",
			data: {'id' : id,"_token": "{{ csrf_token() }}"},
			success: function(data){
				$(tr).remove();
			}
		});
		},
		cancel: function () {}
		}
	}); 	
   });
   
   $('.search').click(function(){
	   
	   var st = $('#startdate').val();
	   var en = $('#enddate').val();
	   var tag = $('#eventtags').val();
	   //alert(st);
	   //return false;
   	$('#example').DataTable({
   	  processing: true,
   	  serverSide: true,
   	  ajax:{
   	   url: "{{ url('searchevent') }}",
   	   type: "POST",
   	   data: {"_token": "{{ csrf_token() }}",'st':st,'en':en,"tag":tag},
   	  },
   	  columns:[
   	  { data: 'event',name: 'event'},
   	  { data: 'start_date',name: 'start_date' },
   	  { data: 'end_date',name: 'end_date' },
   	  { data: 'place',name: 'place'},
   	  { data: 'tags',name: 'tags'},
   	  { data: 'price',name: 'price'},
   	  { data: 'action',name: 'action',orderable: false},],
   	  bDestroy: true,
   	});
	});
	$('.date').datepicker({
      autoclose: true,
	  dateFormat: 'dd-mm-yy'
    })
</script>
</div>
@endsection