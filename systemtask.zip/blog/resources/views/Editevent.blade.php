@extends('layouts.master')

@section('content')
<style>
.error{
	color:red;
}
</style>

<div class="content-wrapper">
   <div class="container">
      <section class="content">
         <div class="row">
            <div class="box">
               <div class="box-header">
                  <h3 class="box-title"><b>Edit Event Management</b></h3>
               </div>
			   
               <div class="box-body">
                  <form class="form-horizontal" action="{{url('updateevent')}}" method="post">
				  <input type="hidden" name="eventid" value="{{$data->id}}">
				  @csrf
              <div class="box-body">
                <div class="form-group">
                  <label class="col-sm-2 control-label">Event Name</label>

                  <div class="col-sm-3">
                    <input type="text" name="eventname" class="form-control" id="eventname" value="{{$data->event}}" readonly>
					@if ($errors->has('eventname'))
						<div class="error">{{ $errors->first('eventname') }}</div>
					@endif
                  </div>
                </div>
                <div class="form-group">
                  <label  class="col-sm-2 control-label">Event Start Date</label>

                  <div class="col-sm-3">
                    <input type="text" class="form-control" name="startdate" id="startdate" value="{{date('d-m-Y',strtotime($data->start_date))}}" required>
					@if ($errors->has('startdate'))
						<div class="error">{{ $errors->first('startdate') }}</div>
					@endif
                  </div>
                </div>
				 <div class="form-group">
                  <label  class="col-sm-2 control-label">Event End Date</label>

                  <div class="col-sm-3">
                    <input type="text" class="form-control" name="enddate" id="enddate" value="{{date('d-m-Y',strtotime($data->end_date))}}" required>
					@if ($errors->has('enddate'))
						<div class="error">{{ $errors->first('enddate') }}</div>
					@endif
                  </div>
                </div>
				<div class="form-group">
                  <label  class="col-sm-2 control-label">Event Place</label>

                  <div class="col-sm-3">
                    <input type="text" class="form-control" name="eventplace" id="eventplace" value="{{$data->place}}" required>
					@if ($errors->has('eventplace'))
						<div class="error">{{ $errors->first('eventplace') }}</div>
					@endif
                  </div>
                </div>
				<div class="form-group">
                  <label  class="col-sm-2 control-label">Event Tags</label>

                  <div class="col-sm-3">
					<select name="eventtags" id="eventtags" class="form-control" required >
						<option value="">Select Tags</option>
						<option value="Red"{{ $data->tags == 'Red' ? 'selected' : '' }} >Red</option>
						<option value="Green" {{ $data->tags == 'Green' ? 'selected' : '' }}>Green</option>
						<option value="Blue" {{ $data->tags == 'Blue' ? 'selected' : '' }}>Blue</option>
						<option value="Yellow" {{ $data->tags == 'Yellow' ? 'selected' : '' }}>Yellow</option>
					</select>
					@if ($errors->has('eventtags'))
						<div class="error">{{ $errors->first('eventtags') }}</div>
					@endif
                  </div>
                </div>
				<div class="form-group">
                  <label  class="col-sm-2 control-label">Event Price</label>

                  <div class="col-sm-3">
                    <input type="text" class="form-control" name="eventprice" id="eventprice" value="{{$data->price}}" required>
					@if ($errors->has('eventprice'))
						<div class="error">{{ $errors->first('eventprice') }}</div>
					@endif
                  </div>
                </div>
				<div class="form-group">
                  <label  class="col-sm-2 control-label"></label>

                  <div class="col-sm-3">
                    <input type="submit" class="form-control btn btn-primary" value="Update">
                  </div>
                </div>
            </form>
               </div>
            </div>
         </div>
      </section>
   </div>
</div>
 <link rel="stylesheet" href="{{url('css/daterangepicker.css')}}">
 <script src="{{url('js/daterangepicker.js')}}"></script>
 <script>
     $('#startdate').datepicker({
      autoclose: true,
	  dateFormat: 'dd-mm-yy'
    })
	$('#enddate').datepicker({
      autoclose: true,
	  dateFormat: 'dd-mm-yy'
    })
 </script>
@endsection