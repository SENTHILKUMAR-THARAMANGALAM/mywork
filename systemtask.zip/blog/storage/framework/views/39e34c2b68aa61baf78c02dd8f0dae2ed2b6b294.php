<?php $__env->startSection('content'); ?>
<style>
.error{
	color:red;
}
</style>

<div class="content-wrapper">
   <div class="container">
      <section class="content">
         <div class="row">
            <div class="box">
               <div class="box-header">
                  <h3 class="box-title"><b>Edit Event Management</b></h3>
               </div>
			   
               <div class="box-body">
                  <form class="form-horizontal" action="<?php echo e(url('updateevent')); ?>" method="post">
				  <input type="hidden" name="eventid" value="<?php echo e($data->id); ?>">
				  <?php echo csrf_field(); ?>
              <div class="box-body">
                <div class="form-group">
                  <label class="col-sm-2 control-label">Event Name</label>

                  <div class="col-sm-3">
                    <input type="text" name="eventname" class="form-control" id="eventname" value="<?php echo e($data->event); ?>" readonly>
					<?php if($errors->has('eventname')): ?>
						<div class="error"><?php echo e($errors->first('eventname')); ?></div>
					<?php endif; ?>
                  </div>
                </div>
                <div class="form-group">
                  <label  class="col-sm-2 control-label">Event Start Date</label>

                  <div class="col-sm-3">
                    <input type="text" class="form-control" name="startdate" id="startdate" value="<?php echo e(date('d-m-Y',strtotime($data->start_date))); ?>" required>
					<?php if($errors->has('startdate')): ?>
						<div class="error"><?php echo e($errors->first('startdate')); ?></div>
					<?php endif; ?>
                  </div>
                </div>
				 <div class="form-group">
                  <label  class="col-sm-2 control-label">Event End Date</label>

                  <div class="col-sm-3">
                    <input type="text" class="form-control" name="enddate" id="enddate" value="<?php echo e(date('d-m-Y',strtotime($data->end_date))); ?>" required>
					<?php if($errors->has('enddate')): ?>
						<div class="error"><?php echo e($errors->first('enddate')); ?></div>
					<?php endif; ?>
                  </div>
                </div>
				<div class="form-group">
                  <label  class="col-sm-2 control-label">Event Place</label>

                  <div class="col-sm-3">
                    <input type="text" class="form-control" name="eventplace" id="eventplace" value="<?php echo e($data->place); ?>" required>
					<?php if($errors->has('eventplace')): ?>
						<div class="error"><?php echo e($errors->first('eventplace')); ?></div>
					<?php endif; ?>
                  </div>
                </div>
				<div class="form-group">
                  <label  class="col-sm-2 control-label">Event Tags</label>

                  <div class="col-sm-3">
					<select name="eventtags" id="eventtags" class="form-control" required >
						<option value="">Select Tags</option>
						<option value="Red"<?php echo e($data->tags == 'Red' ? 'selected' : ''); ?> >Red</option>
						<option value="Green" <?php echo e($data->tags == 'Green' ? 'selected' : ''); ?>>Green</option>
						<option value="Blue" <?php echo e($data->tags == 'Blue' ? 'selected' : ''); ?>>Blue</option>
						<option value="Yellow" <?php echo e($data->tags == 'Yellow' ? 'selected' : ''); ?>>Yellow</option>
					</select>
					<?php if($errors->has('eventtags')): ?>
						<div class="error"><?php echo e($errors->first('eventtags')); ?></div>
					<?php endif; ?>
                  </div>
                </div>
				<div class="form-group">
                  <label  class="col-sm-2 control-label">Event Price</label>

                  <div class="col-sm-3">
                    <input type="text" class="form-control" name="eventprice" id="eventprice" value="<?php echo e($data->price); ?>" required>
					<?php if($errors->has('eventprice')): ?>
						<div class="error"><?php echo e($errors->first('eventprice')); ?></div>
					<?php endif; ?>
                  </div>
                </div>
				<div class="form-group">
                  <label  class="col-sm-2 control-label"></label>

                  <div class="col-sm-3">
                    <input type="submit" class="form-control btn btn-primary" value="Update">
                  </div>
                </div>
            </form>
               </div>
            </div>
         </div>
      </section>
   </div>
</div>
 <link rel="stylesheet" href="<?php echo e(url('css/daterangepicker.css')); ?>">
 <script src="<?php echo e(url('js/daterangepicker.js')); ?>"></script>
 <script>
     $('#startdate').datepicker({
      autoclose: true,
	  dateFormat: 'dd-mm-yy'
    })
	$('#enddate').datepicker({
      autoclose: true,
	  dateFormat: 'dd-mm-yy'
    })
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/Editevent.blade.php ENDPATH**/ ?>