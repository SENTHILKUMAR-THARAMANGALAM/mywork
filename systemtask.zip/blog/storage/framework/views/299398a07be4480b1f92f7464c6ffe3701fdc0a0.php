<?php $__env->startSection('content'); ?>
<style>
   .error{
   color:red;
   }
</style>
<div class="content-wrapper">
<div class="container">
   <section class="content">
      <div class="row">
         <div class="box">
            <div class="box-header">
               <h3 class="box-title"><b>Add Event Management</b></h3>
            </div>
            <div class="box-body">
               <form class="form-horizontal" action="<?php echo e(url('addevent')); ?>" method="post" autocomplete="off">
                  <?php echo csrf_field(); ?>
                  <div class="box-body">
                     <div class="form-group">
                        <label class="col-sm-2 control-label">Event Name</label>
                        <div class="col-sm-3">
                           <input type="text" name="eventname" class="form-control" id="eventname" placeholder="Event Name" required>
                           <?php if($errors->has('eventname')): ?>
                           <div class="error"><?php echo e($errors->first('eventname')); ?></div>
                           <?php endif; ?>
                        </div>
                     </div>
                     <div class="form-group">
                        <label  class="col-sm-2 control-label">Event Start Date</label>
                        <div class="col-sm-3">
                           <input type="text" class="form-control" name="startdate" id="startdate" placeholder="Start Date" required>
                           <?php if($errors->has('startdate')): ?>
                           <div class="error"><?php echo e($errors->first('startdate')); ?></div>
                           <?php endif; ?>
                        </div>
                     </div>
                     <div class="form-group">
                        <label  class="col-sm-2 control-label">Event End Date</label>
                        <div class="col-sm-3">
                           <input type="text" class="form-control" name="enddate" id="enddate" placeholder="End Date" required>
                           <?php if($errors->has('enddate')): ?>
                           <div class="error"><?php echo e($errors->first('enddate')); ?></div>
                           <?php endif; ?>
                        </div>
                     </div>
                     <div class="form-group">
                        <label  class="col-sm-2 control-label">Event Place</label>
                        <div class="col-sm-3">
                           <input type="text" class="form-control" name="eventplace" id="eventplace" placeholder="Event Place" required>
                           <?php if($errors->has('eventplace')): ?>
                           <div class="error"><?php echo e($errors->first('eventplace')); ?></div>
                           <?php endif; ?>
                        </div>
                     </div>
                     <div class="form-group">
                        <label  class="col-sm-2 control-label">Event Tags</label>
                        <div class="col-sm-3">
                           <select name="eventtags" id="eventtags" class="form-control" required >
                              <option value="">Select Tags</option>
                              <option value="Red"<?php echo e(old('eventtags') == 'Red' ? 'selected' : ''); ?> >Red</option>
                              <option value="Green" <?php echo e(old('eventtags') == 'Green' ? 'selected' : ''); ?>>Green</option>
                              <option value="Blue" <?php echo e(old('eventtags') == 'Blue' ? 'selected' : ''); ?>>Blue</option>
                              <option value="Yellow" <?php echo e(old('eventtags') == 'Yellow' ? 'selected' : ''); ?>>Yellow</option>
                           </select>
                           <?php if($errors->has('eventtags')): ?>
                           <div class="error"><?php echo e($errors->first('eventtags')); ?></div>
                           <?php endif; ?>
                        </div>
                     </div>
                     <div class="form-group">
                        <label  class="col-sm-2 control-label">Event Price</label>
                        <div class="col-sm-3">
                           <input type="text" class="form-control" name="eventprice" id="eventprice" placeholder="Event Price" required>
                           <?php if($errors->has('eventprice')): ?>
                           <div class="error"><?php echo e($errors->first('eventprice')); ?></div>
                           <?php endif; ?>
                        </div>
                     </div>
                     <div class="form-group">
                        <label  class="col-sm-2 control-label"></label>
                        <div class="col-sm-3">
                           <input type="submit" class="form-control btn btn-primary">
                        </div>
                     </div>
               </form>
               </div>
            </div>
         </div>
   </section>
   </div>
</div>
<link rel="stylesheet" href="<?php echo e(url('css/daterangepicker.css')); ?>">
<script src="<?php echo e(url('js/daterangepicker.js')); ?>"></script>
<script>
   $('#startdate').datepicker({
    autoclose: true,
   dateFormat: 'dd-mm-yy',
   minDate : 0,
   })
   $('#enddate').datepicker({
    autoclose: true,
   dateFormat: 'dd-mm-yy',
   minDate : 0,
   })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/Newevent.blade.php ENDPATH**/ ?>