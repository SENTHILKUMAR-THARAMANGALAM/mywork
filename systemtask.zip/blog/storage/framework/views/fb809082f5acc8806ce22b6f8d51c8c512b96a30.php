<script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('js/mywork.min.js')); ?>"></script>
<script src="<?php echo e(url('js/demo.js')); ?>"></script>
<script src="<?php echo e(url('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(url('js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(url('js/jquery-confirm.min.js')); ?>"></script>
<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>My Work</b>
      </div>
      <strong>Copyright © <?php echo date('Y'); ?>  All rights reserved.</strong>
    </div>
  </footer>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/partials/footer.blade.php ENDPATH**/ ?>