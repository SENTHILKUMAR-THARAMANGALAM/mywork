<?php
namespace App\Http\Controllers;
use App\Models\Page;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\User;
use Session;

class LoginController extends Controller
{
	
    public function index()
    {
        return view('Login');
    }   

	public function check(Request $request)
    {
		$userid = $request->input('useremail');
		$password = $request->input('password');
		
		if (Auth::attempt(['email' => $userid,'password'=>$password,'status'=>'1'])) {
          
			$data =  DB::table('users')->where('email', $userid)->first();
			$id = $data->id;
			Session::put('loginuser',$id);
			//print_r($id);
			return redirect('dashboard');
        } 
		else
		{
			return redirect('login')->with('message', 'FAILED');  
		}
    }
	
	public function logout()
    {
         Session::flush();
		return redirect('login');
    }   
}