<?php
namespace App\Http\Controllers;
use App\Models\Page;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Dashboard;
use Session;
use Redirect; 
use Datatables; 
class DashboardController extends Controller
{
    public function index()
    {
		$session = Session::get('loginuser');
		if(empty($session))
		{
			return redirect('login');
		}
		
        return view('Dashboard');
    }
	
	public function ajaxevent(Request $request)
    {
       // $data = Dashboard::orderBy('id','DESC')->get();
		
		return datatables()->of(Dashboard::latest()->get())->addColumn('action', function($data){
                $button = '<a href="editevent?id='.$data->id.'"><button type="button" name="edit" data-id="'.$data->id.'" class="edit btn btn-primary btn-sm">Edit</button></a>';
                $button .= '&nbsp;&nbsp;';
                $button .= '<button type="button" name="delete" data-id="'.$data->id.'" class="delete btn btn-danger btn-sm">Delete</button>';
                return $button;
                })->rawColumns(['action'])->make(true);
    } 
	
	public function searchevent(Request $request)
    {
		$query = Dashboard::query();
		if(!empty($_POST['en'])) { $en = $_POST['en']; } else { $en = ''; }
		if(!empty($en)) $d = $query->where('end_date','<=',date('Y-m-d',strtotime($en)));
		
		if(!empty($_POST['st'])) { $st = $_POST['st']; } else { $st = ''; }
		if(!empty($st)) $d = $query->where('start_date','>=',date('Y-m-d',strtotime($st)));
		
		if(!empty($_POST['tag'])) { $tag = $_POST['tag']; } else { $tag = ''; }
		if(!empty($tag)) $d = $query->where('tags',$tag);
		
		if($en == '' && $st == '' && $tag == '')
		{
			$final = Dashboard::latest()->get();
		}
		else
		{
			$final = $d->get();
		}
		
		return datatables()->of($final)->addColumn('action', function($data){
                $button = '<a href="editevent?id='.$data->id.'"><button type="button" name="edit" data-id="'.$data->id.'" class="edit btn btn-primary btn-sm">Edit</button></a>';
                $button .= '&nbsp;&nbsp;';
                $button .= '<button type="button" name="delete" data-id="'.$data->id.'" class="delete btn btn-danger btn-sm">Delete</button>';
                return $button;
                })->rawColumns(['action'])->make(true);
    } 

	public function deleteevent(Request $request)
    {
        $id = $request->input('id');
		$res=Dashboard::where('id',$id)->delete();
		echo $res;
    }	
	
	public function editevent()
    {
		$session = Session::get('loginuser');
		if(empty($session))
		{
			return redirect('login');
		}
        $id  = $_GET['id'];
		$data = Dashboard::where('id',$id)->first();
		//print_r($data); exit;
		return view('Editevent',['data'=>$data]);
    }
	
	public function newevent()
    {
		$session = Session::get('loginuser');
		if(empty($session))
		{
			return redirect('login');
		}
        return view('Newevent');
    }
	
	public function addevent(Request $request)
    {	
		$rules = [
			'eventname' => 'required',
			'startdate' => 'required|date|date_format:d-m-Y|before:enddate',
			'enddate' => 'required|date|date_format:d-m-Y|after:startdate',
			'eventplace' => 'required',
			'eventtags' => 'required',
			'eventprice' => 'required|numeric'
		];

		$messages = [
			'eventname.required' => 'Enter event name',
			'startdate.required' => 'Select event start date',
			'startdate.before' => 'Select proper event start date',
			'enddate.after' => 'Select proper event end date',
			'enddate.required' => 'Select event end date',
			'eventplace.required' => 'Enter event place',
			'eventtags.required' => 'Select event tags',
			'eventprice.required' => 'Enter event price',
			'eventprice.numeric' => 'Enter Only Number',
		];

		$validator = Validator::make($request->all(), $rules, $messages);
		if ($validator->fails()) {
			return Redirect::back()->withErrors($validator)->withInput();
		}
		else
		{
			$startdate = date('Y-m-d',strtotime($_POST['startdate']));
			$enddate = date('Y-m-d', strtotime($_POST['enddate']));
			
			$event = new Dashboard();
			
			$event->event = $request->input('eventname');
			$event->start_date = $startdate;
			$event->end_date = $enddate;
			$event->place = $request->input('eventplace');
			$event->tags = $request->input('eventtags');
			$event->price = $request->input('eventprice');
			$event->save();
			return redirect('dashboard');
		}
    }
	
	public function updateevent (Request $request)
    {	
		$rules = [
			'eventname' => 'required',
			'startdate' => 'required|date|date_format:d-m-Y|before:enddate',
			'enddate' => 'required|date|date_format:d-m-Y|after:startdate',
			'eventplace' => 'required',
			'eventtags' => 'required',
			'eventprice' => 'required|numeric'
		];

		$messages = [
			'eventname.required' => 'Enter event name',
			'startdate.required' => 'Select event start date',
			'startdate.before' => 'Select proper event start date',
			'enddate.after' => 'Select proper event end date',
			'enddate.required' => 'Select event end date',
			'eventplace.required' => 'Enter event place',
			'eventtags.required' => 'Select event tags',
			'eventprice.required' => 'Enter event price',
			'eventprice.numeric' => 'Enter Only Number',
		];

		$validator = Validator::make($request->all(), $rules, $messages);
		if ($validator->fails()) {
			return Redirect::back()->withErrors($validator)->withInput();
		}
		else
		{
			$id = $request->input('eventid');
			$startdate = date('Y-m-d',strtotime($_POST['startdate']));
			$enddate = date('Y-m-d', strtotime($_POST['enddate']));
			$start_date = $startdate;
			$end_date = $enddate;
			$place = $request->input('eventplace');
			$tags = $request->input('eventtags');
			$price = $request->input('eventprice');
			
			$update = DB::table('event_management')->where('id',$id )->update(['start_date' => $startdate,'end_date' => $enddate,'place' =>$place,'tags' =>$tags,'price'=>$price ]);
			
			return redirect('dashboard');
			
		}
    }
}