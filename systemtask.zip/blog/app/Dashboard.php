<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dashboard extends Model
{
    protected $table = 'event_management';
	
    protected $fillable = ['id','event','start_date','end_date','place','tags','price'];
}
