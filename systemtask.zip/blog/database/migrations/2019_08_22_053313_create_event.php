<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEvent extends Migration
{
    public function up()
    {
        Schema::create('event_management', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('event');
			$table->date('start_date');
			$table->date('end_date');
			$table->string('place');
			$table->string('tags');
			$table->string('price');
			$table->enum('status', ['0','1']);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('event_management');
    }
}
